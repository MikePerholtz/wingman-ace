﻿using System;

namespace WingmanBusiness
{
    public class Class1
    {
    }
}
